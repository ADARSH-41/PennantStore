package models;

public class Customer {

	private int cid;
	private String cname;
	private String cpassword;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCPassword() {
		return cpassword;
	}
	public void setCPassword(String cpassword) {
		this.cpassword = cpassword;
	}
	
}
