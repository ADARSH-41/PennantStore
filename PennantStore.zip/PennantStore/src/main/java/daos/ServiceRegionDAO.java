package daos;


public interface ServiceRegionDAO {

	public boolean checkAvailability(int pin);
}
