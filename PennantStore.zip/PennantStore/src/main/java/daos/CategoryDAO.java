package daos;

import java.util.List;

import models.Category;

public interface CategoryDAO {
	
	public List<Category> getAllCategories();

}
